import { UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Test } from '@nestjs/testing';
import { beforeEach, describe, expect, it, vi } from 'vitest';

import type { JwtPayload } from '@quickdialog/auth/schemas/jwt-payload.schema.js';
import { JwtStrategy } from '@quickdialog/auth/strategies/jwt.strategy.js';

describe('JwtStrategy', () => {
  let strategy: JwtStrategy;

  const configService = {
    getOrThrow: vi.fn((key: string) => {
      const values: Record<string, string> = {
        'auth.accessToken.secret': 'test-secret-at-least-32-characters-long',
        'auth.accessToken.issuer': 'quickdialog-api',
        'auth.accessToken.audience': 'quickdialog-web',
      };

      return values[key];
    }),
  };

  beforeEach(async () => {
    vi.clearAllMocks();

    const moduleRef = await Test.createTestingModule({
      providers: [
        JwtStrategy,
        {
          provide: ConfigService,
          useValue: configService,
        },
      ],
    }).compile();

    strategy = moduleRef.get(JwtStrategy);
  });

  it('is defined', () => {
    expect(strategy).toBeDefined();
  });

  it('maps a valid payload to AuthenticatedUser', () => {
    const result = strategy.validate({
      sub: '4e3ee6a0-eec9-47c8-9fe3-e92afe8a2b1b',
      sid: '8d234fad-ceec-4f64-bb1b-1459c0b16cd7',
      hotelId: 'c5497c67-4e65-4644-bbb9-e9fb40f76627',
      role: 'OWNER',
    });

    expect(result).toEqual({
      userId: '4e3ee6a0-eec9-47c8-9fe3-e92afe8a2b1b',
      sessionId: '8d234fad-ceec-4f64-bb1b-1459c0b16cd7',
      hotelId: 'c5497c67-4e65-4644-bbb9-e9fb40f76627',
      role: 'OWNER',
    });
  });

  it('rejects an invalid payload', () => {
    expect(() =>
      strategy.validate({
        sub: '',
        sid: 'invalid',
        hotelId: 'c5497c67-4e65-4644-bbb9-e9fb40f76627',
        role: 'OWNER',
      }),
    ).toThrow(UnauthorizedException);
  });

  it('rejects hotel-bound roles without a valid hotel ID', () => {
    expect(() =>
      strategy.validate({
        sub: '4e3ee6a0-eec9-47c8-9fe3-e92afe8a2b1b',
        sid: '8d234fad-ceec-4f64-bb1b-1459c0b16cd7',
        hotelId: null,
        role: 'OWNER',
      } as unknown as JwtPayload),
    ).toThrow(UnauthorizedException);
  });

  it('allows a super admin without a hotel ID', () => {
    expect(
      strategy.validate({
        sub: '4e3ee6a0-eec9-47c8-9fe3-e92afe8a2b1b',
        sid: '8d234fad-ceec-4f64-bb1b-1459c0b16cd7',
        hotelId: null,
        role: 'SUPER_ADMIN',
      }),
    ).toMatchObject({ hotelId: null, role: 'SUPER_ADMIN' });
  });
});
